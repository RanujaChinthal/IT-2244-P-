//user going to input 5,2 to parent process,
//parent sent 5,2 to shared memory,shared memory sent(5,2) to child process,
//child process calculate factorial and return 5!,2!
//and parent process print nPr,nCr


#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <sys/wait.h>

#define SHM_SIZE 1024  // size of shared memory

// Struct to hold inputs and results in shared memory
typedef struct {
    int n;
    int r;
    unsigned long long nFact;
    unsigned long long rFact;
    unsigned long long nMinusRFact;
} SharedData;

// Factorial function
unsigned long long factorial(int num) {
    if (num <= 1) return 1;
    unsigned long long fact = 1;
    for (int i = 2; i <= num; i++) {
        fact *= i;
    }
    return fact;
}

int main() {
    key_t key = ftok("shmfile2021ict26",65); // generate unique key
    int shmid = shmget(key, SHM_SIZE, 0666|IPC_CREAT);
    if (shmid == -1) {
        perror("shmget failed");
        exit(1);
    }

    SharedData *data = (SharedData*) shmat(shmid, NULL, 0);
    if (data == (void*) -1) {
        perror("shmat failed");
        exit(1);
    }

    // Parent: get inputs from user
    printf("Enter n and r (space separated): ");
    scanf("%d %d", &data->n, &data->r);

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(1);
    }

    if (pid == 0) {
        // Child process
        int n = data->n;
        int r = data->r;

        // Calculate factorials
        data->nFact = factorial(n);
        data->rFact = factorial(r);
        data->nMinusRFact = factorial(n - r);

        // Detach shared memory and exit
        shmdt(data);
        exit(0);
    } else {
        // Parent process: wait for child to finish
        wait(NULL);

        // Calculate nPr and nCr
        unsigned long long nPr = data->nFact / data->nMinusRFact;
        unsigned long long nCr = nPr / data->rFact;

        printf("nPr (%dP%d) = %llu\n", data->n, data->r, nPr);
        printf("nCr (%dC%d) = %llu\n", data->n, data->r, nCr);

        // Detach and remove shared memory
        shmdt(data);
        shmctl(shmid, IPC_RMID, NULL);
    }

    return 0;
}
