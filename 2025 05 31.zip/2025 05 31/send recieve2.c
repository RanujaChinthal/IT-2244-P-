//send

#include<stdio.h>
#include<sys/msg.h>
#define MAX 10

//structure for message queue

struct mesg_buffer{
	long mesg_type;
	char mesg_text[100];
}
message;

int main()
{
	key_t key;
	int msgid;
	
	//ftok to generate unique key
	key=ftok("progfile2021ict26",65);
	
	//msgget creates a message queue and returns identifier
	msgid = msgget(key,0666 | IPC_CREAT);
	message.mesg_type = 1;
	printf("write data :");
	fgets(message.mesg_text,MAX,stdin);
	//msgsnd to send messages
	msgsnd(msgid, &message, sizeof(message),0);
	//display message
	printf("Data send id : %s \n",message.mesg_text);
	
return 0;
}

// recieve

#include<stdio.h>
#include<sys/ipc.h>
#include<sys/msg.h>

//structure for message queue

struct mesg_buffer
{
	long mesg_type;
	char mesg_text[100];
}
message;
int main()
{
	key_t key;
	int msgid;
	//ftok to generate unique key
	key = ftok("progfile2021ict26",65);
	//msgget creates a message queue and returns identifier
	msgid = msgget(key,0666 | IPC_CREAT);
	//msgcrv to recieve message
	msgrcv(msgid, &message, sizeof(message), 1, 0);
	//display message
	printf("Data recieve id : %s \n",message.mesg_text);
    //to destroy the message queue 
	msgctl(msgid, IPC_RMID, NULL);
	
return 0;
}

[2021ict26@fedora ~]$ touch progfile2021ict26
[2021ict26@fedora ~]$ chmod 644 progfile2021ict26

[2021ict26@fedora ~]$ vi send2.c
[2021ict26@fedora ~]$ gcc send2.c -o s2

[2021ict26@fedora ~]$ ./s2
write data :Ranuuu
Data send id : Ranuuu

[2021ict26@fedora ~]$ vi recieve2.c
[2021ict26@fedora ~]$ gcc recieve2.c -o r2
[2021ict26@fedora ~]$ ./r2
Data recieve id : Ranuuu


















